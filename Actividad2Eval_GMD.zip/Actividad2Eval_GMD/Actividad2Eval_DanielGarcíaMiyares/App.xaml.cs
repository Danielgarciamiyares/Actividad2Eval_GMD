﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Actividad2Eval_DanielGarcíaMiyares
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
