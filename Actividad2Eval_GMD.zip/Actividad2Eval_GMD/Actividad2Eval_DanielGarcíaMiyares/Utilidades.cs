﻿using CsvHelper.Configuration;
using System;
using System.Globalization;
using System.IO;
using System.Text;

namespace Actividad2Eval_DanielGarcíaMiyares
{
    internal class Utilidades
    {
        private string nombreArchivo;
        private string rutaBase;
        public string RutaArchivo;

        public CsvConfiguration config;

        public Utilidades()
        {

        }
        public Utilidades(string csv)
        {
            nombreArchivo = csv;
            rutaBase = AppDomain.CurrentDomain.BaseDirectory;
            //rutaBase = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "..", ".."));
            RutaArchivo = Path.Combine(rutaBase, "Data", nombreArchivo);

            config = new CsvConfiguration(CultureInfo.CurrentCulture)
            {
                Delimiter = ";",
                Encoding = Encoding.UTF8
            };
        }
    }
}

