﻿using Actividad2Eval_DanielGarcíaMiyares.Model;
using CsvHelper;
using CsvHelper.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Actividad2Eval_DanielGarcíaMiyares.ViewModel
{
    class LogicaNegocio:DbContext
    {

        public ObservableCollection<Linea> Lineas {  get; set; }
        public ObservableCollection<Parada> Itinerario { get; set; }
        public static LogicaNegocio context = new LogicaNegocio();
        Utilidades u;

        public LogicaNegocio()
        {
            Lineas = new ObservableCollection<Linea>();
            Itinerario = new ObservableCollection<Parada>();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase("InMemoryDatabase");
        }

        public int SaveLineaChanges()
        {
            int retValue = base.SaveChanges();
            saveLineaToCsv();
            return retValue;
        }
        public int SaveItinerarioChanges()
        {
            int retValue = base.SaveChanges();
            saveItinerarioToCsv();
            return retValue;
        }

        private void saveLineaToCsv()
        {
            u = new Utilidades("Lineas.csv");

            using (var writer = new StreamWriter(u.RutaArchivo))
            using (var csvWriter = new CsvWriter(writer, u.config))
            {
                csvWriter.WriteRecords(this.Lineas.ToList());
            }
        }

        private void saveItinerarioToCsv()
        {
            u = new Utilidades("Itinerario.csv");

            using (var writer = new StreamWriter(u.RutaArchivo))
            using (var csvWriter = new CsvWriter(writer, u.config))
            {
                csvWriter.WriteRecords(this.Itinerario.ToList());
            }
        }
    }
}
