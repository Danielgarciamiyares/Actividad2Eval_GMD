﻿using Actividad2Eval_DanielGarcíaMiyares.Model;
using Actividad2Eval_DanielGarcíaMiyares.View.Pags;
using Actividad2Eval_DanielGarcíaMiyares.ViewModel;
using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Actividad2Eval_DanielGarcíaMiyares.View
{
    /// <summary>
    /// Lógica de interacción para LineaView.xaml
    /// </summary>
    public partial class LineaView : Window
    {
        public static List<Linea> lstLineas = new List<Linea>();  /*{ get; set; }*/

        public LineaView()
        {
            InitializeComponent();
            fillDataGrid();
        }

        
        private LogicaNegocio context = LogicaNegocio.context;

        private void btnAñadir_Click(object sender, RoutedEventArgs e)
        {
            frmLinea.NavigationService.Navigate(new AñadirLinea());
        }
        private void btnModificar_Click(object sender, RoutedEventArgs e)
        {
            Linea l = dgLineas.SelectedItem as Linea;
            frmLinea.NavigationService.Navigate(new AñadirLinea(l));
        }

        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            context.Lineas.Remove(dgLineas.SelectedItem as Linea);
            context.SaveLineaChanges();
        }
        private void btnFiltrar_Click(object sender, RoutedEventArgs e)
        {
            filtrar();
        }

        private void btnAtras_Click(object sender, RoutedEventArgs e)
        {
            this.DataContext = context;
            MainWindow ventanaPrincipal = new MainWindow();
            context.Lineas.Clear();

            this.Close();
            ventanaPrincipal.Show();
        }



        private void dgLineas_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Linea linea = dgLineas.SelectedItem as Linea;
            ItinerarioView ventanaItinerario = new ItinerarioView(linea.numLinea);

            this.Close();
            ventanaItinerario.Show();
        }



        private void fillDataGrid()
        {
            this.DataContext = context;
            Utilidades u = new Utilidades("Lineas.csv");

            using (var reader = new StreamReader(u.RutaArchivo))
            using (var csv = new CsvReader(reader, u.config))
            {

                lstLineas = new List<Linea>(csv.GetRecords<Linea>().ToList());
                lstLineas.ForEach(l => context.Lineas.Add(l));
            }
        }

        /*TODO revisar */
        public void filtrar()
        {
            List<Linea> lstFiltrada = new List<Linea>();
            //ItinerarioView IV = new ItinerarioView();

            if (txtFiltro.Text.Trim() == "")
            {
                MessageBox.Show("Ingrese el valor a filtrar");
            }
            else
            {
                if (rbtnSalida.IsChecked == false && rbtnDestino.IsChecked == false)
                {
                    MessageBox.Show("Seleccione el tipo de búsqueda");
                }
                else
                {
                    if (rbtnSalida.IsChecked == true)
                    {
                        foreach (Linea l in LineaView.lstLineas.Where(l => l.horaInicial.Hour.Equals( DateTime.Parse(txtFiltro.Text.ToString()).Hour)))
                        {
                            lstFiltrada.Add(l);
                        }
                    }

                    if (rbtnDestino.IsChecked == true)
                    {
                        foreach (Linea l in LineaView.lstLineas.Where(l => l.municipioDestino.ToUpper().Contains(txtFiltro.Text.ToString().ToUpper())))
                        {
                            lstFiltrada.Add(l);
                        }
                    }
                    dgLineas.ItemsSource = lstFiltrada;
                }
            }
        }



    }
}
