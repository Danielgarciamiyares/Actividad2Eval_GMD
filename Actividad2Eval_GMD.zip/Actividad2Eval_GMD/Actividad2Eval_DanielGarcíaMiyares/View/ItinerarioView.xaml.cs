﻿using Actividad2Eval_DanielGarcíaMiyares.Model;
using Actividad2Eval_DanielGarcíaMiyares.View.Pags.PagsItinerario;
using Actividad2Eval_DanielGarcíaMiyares.ViewModel;
using CsvHelper;
using System.IO;
using System.Windows;


namespace Actividad2Eval_DanielGarcíaMiyares.View
{
    /// <summary>
    /// Lógica de interacción para ItinerarioView.xaml
    /// </summary>
    public partial class ItinerarioView : Window
    {

        public static List<Parada> lstItinerario = new List<Parada>();

        public ItinerarioView()
        {
            InitializeComponent();
            fillDataGrid();
        }

        public ItinerarioView(int nLinea)
        {
            InitializeComponent();
            fillDataGrid();

            rbtnNLinea.IsChecked = true;
            txtFiltro.Text = nLinea.ToString();
            

            filtrar();
            context.Lineas.Clear();


        }

        //private List<Itinerario> LstItinerarios { get; set; }/*TODO revisar*/
        //  private AppLineasDBContext context = new AppLineasDBContext();
        private LogicaNegocio context = LogicaNegocio.context /*new LogicaNegocio()*/;
        private void btnAñadir_Click(object sender, RoutedEventArgs e)
        {
            frmItinerario.NavigationService.Navigate(new AñadirItinerario());
        }

        private void btnModificar_Click(object sender, RoutedEventArgs e)
        {
            Parada p = dgItinerario.SelectedItem as Parada;

            frmItinerario.NavigationService.Navigate(new AñadirItinerario(p));


        }

        private void btnEliminar_Click(object sender, RoutedEventArgs e)
        {
            //context.Itinerario.Remove(dgItinerario.SelectedItem as Itinerario);
            context.Itinerario.Remove(dgItinerario.SelectedItem as Parada);
            context.SaveItinerarioChanges();
        }

        private void btnFiltrar_Click(object sender, RoutedEventArgs e)
        {
            filtrar();
        }

        private void btnAtras_Click(object sender, RoutedEventArgs e)
        {
            this.DataContext = context;
            MainWindow ventanaPrincipal = new MainWindow();

            //lstItinerario = new List<Parada>();
            context.Itinerario.Clear();

            this.Close();
            ventanaPrincipal.Show();
        }


        public void fillDataGrid()
        {
            this.DataContext = context;

            Utilidades u = new Utilidades("Itinerario.csv");
            //LogicaNegocio context = new LogicaNegocio();
            //List<Itinerario> lstItinerario = new List<Itinerario>();
            //lstItinerario = new List<Parada>();


            using (var reader = new StreamReader(u.RutaArchivo))/*u.RutaArchivo*//*"E:\\DEDI\\Actividad2Eval\\Actividad2Eval_DanielGarcíaMiyares\\Actividad2Eval_DanielGarcíaMiyares\\Data\\Itinerario.csv"*/
            using (var csv = new CsvReader(reader, u.config))
            {
                //lstItinerario = new List<Itinerario>(csv.GetRecords<Itinerario>().ToList());
                lstItinerario = new List<Parada>(csv.GetRecords<Parada>().ToList());
                lstItinerario.ForEach(i => context.Itinerario.Add(i));
            }
        }





        /* Metodo para filtrar la lista de las paradas en base a un radio button pulsado y el texto introducido en el campo filtro */
        public void filtrar()
        {
            List<Parada> lstFiltrada = new List<Parada>();
            
            if (txtFiltro.Text.Trim() == "")
            {
                MessageBox.Show("Ingrese el valor a filtrar");
            }
            else
            {
                if (rbtnNLinea.IsChecked == false && rbtnMunicipio.IsChecked == false)
                {
                    MessageBox.Show("Seleccione el tipo de búsqueda");
                }
                else
                {
                    if (rbtnNLinea.IsChecked == true)
                    {
                        foreach (Parada p in ItinerarioView.lstItinerario.Where(p => p.numLinea == int.Parse(txtFiltro.Text.ToString() )))
                        {
                            
                            lstFiltrada.Add(p);


                        }
                       
                    }

                    if (rbtnMunicipio.IsChecked == true)
                    {
                        foreach (Parada p in ItinerarioView.lstItinerario.Where(p => p.municipio.ToUpper().Contains(txtFiltro.Text.ToString().ToUpper())))
                        {

                            lstFiltrada.Add(p);


                        }
                    }
                    dgItinerario.ItemsSource = lstFiltrada;
                }
            }



        }


    }
}
