﻿using Actividad2Eval_DanielGarcíaMiyares.Model;
using Actividad2Eval_DanielGarcíaMiyares.ViewModel;
using CsvHelper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Actividad2Eval_DanielGarcíaMiyares.View.Pags
{
    /// <summary>
    /// Lógica de interacción para AñadirLinea.xaml
    /// </summary>
    /// 


    public partial class AñadirLinea : Page
    {
        private Boolean hayLinea = false;
        Linea oldLinea;
        public AñadirLinea()
        {
            InitializeComponent();
            fillCombo();
        }

        public AñadirLinea(Linea l)
        {
            InitializeComponent();
            fillCombo();
            oldLinea= l;
            LineaModif(oldLinea);
            hayLinea = true;

        }

        private void btnAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (!hayLinea) 
            { 
                if (!campoVacio()) 
                {
                    int newKey = CalcularNLinea();
                    if (cmbOrigen.SelectedValue.ToString().Equals(cmbDestino.SelectedValue.ToString()))
                    {
                        MessageBox.Show("El municipio de origen y el municipio de destino no pueden ser el mismo");
                    }
                    else
                    {


                        ///*TODO cambiar*/
                        //string formato = "HH:mm";
                        //// Intenta analizar el intervalo de tiempo utilizando el formato especificado
                        //TimeOnly intervalo = TimeOnly.ParseExact(Intervalo.Text.ToString(), formato, CultureInfo.InvariantCulture);

                        /*---------------------------------------------------------------------------------------*/

                        Linea l = new Linea(newKey, cmbOrigen.SelectedValue.ToString(), cmbDestino.SelectedValue.ToString(), DateTime.Parse(cmbHora.Text + " " + dpLinea.Text), TimeOnly.Parse(Intervalo.Text.ToString()));/*TimeOnly.Parse(Intervalo.Text.ToString())*/
                        LogicaNegocio.context.Lineas.Add(l);
                        LogicaNegocio.context.SaveLineaChanges();
                        this.Visibility = Visibility.Collapsed;/*Borra la pagina*/
                    }
                }
                else
                {
                    MessageBox.Show("No puede haber ningún campo vacio");
                }
            }
            else
            {
                if (!campoVacio())
                {
                    int newKey = -1;
                    newKey = oldLinea.numLinea;
                    if (cmbOrigen.SelectedValue.ToString().Equals(cmbDestino.SelectedValue.ToString()))
                    {
                        MessageBox.Show("El municipio de origen y el municipio de destino no pueden ser el mismo");
                    }
                    else
                    {
                        Linea l = new Linea(newKey, cmbOrigen.SelectedValue.ToString(), cmbDestino.SelectedValue.ToString(), DateTime.Parse(cmbHora.Text + " " + dpLinea.Text), TimeOnly.Parse(Intervalo.Text.ToString()));/*TODO revisar si pongo intervalo 00:30 sale 12:30*/
                        LogicaNegocio.context.Lineas.Add(l);
                        LogicaNegocio.context.Lineas.Remove(oldLinea);
                        LogicaNegocio.context.SaveLineaChanges();
                        this.Visibility = Visibility.Collapsed;/*Borra la pagina*/
                    }

                }
                else
                {
                    MessageBox.Show("No puede haber ningún campo vacio");
                }
            }
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Visibility=Visibility.Collapsed;/*Borra la pagina*/
        }


        /* Metodo para llenar el combo box de municipios con todos los datos de Municipios.csv*/
        private void fillCombo()
        {
            List<Municipio> lstMunicipio = new List<Municipio>();

            Utilidades u = new Utilidades("Municipios.csv");



            var reader = new StreamReader(u.RutaArchivo);
            using (var csv = new CsvReader(reader, u.config))
            {
                lstMunicipio = new List<Municipio>(csv.GetRecords<Municipio>().ToList());
           
            }


            this.cmbOrigen.DisplayMemberPath = "NOMBRE";
            this.cmbOrigen.SelectedValuePath = "NOMBRE";
            this.cmbOrigen.ItemsSource = lstMunicipio;

            this.cmbDestino.DisplayMemberPath = "NOMBRE";
            this.cmbDestino.SelectedValuePath = "NOMBRE";
            this.cmbDestino.ItemsSource = lstMunicipio;
        }

        /* Metodo para validar si hay algún campo vacío en la interfaz
        * Si algún campo esta vacio devuelve true*/
        private bool campoVacio()
        {
            bool ret = false;

            if (cmbOrigen.SelectedIndex == -1 || cmbDestino.SelectedIndex == -1 ||cmbHora.Text.Trim().Length == 0 || Intervalo.Text.Trim().Length == 0 )
            {
                ret = true;
            }
            else
            {
                ret= false;
            }
            return ret;
        }


        /* Metod para calcular el número de la parada 
        * Si no hubiese ninguna parada le asigna el numero de parada 1
        * Si ya hay alguna le asigna el numero siguiente de la última parada*/
        private int CalcularNLinea()
        {
            int ret = 0;

            if ((LogicaNegocio.context.Lineas.Count) == 0)
            {
                ret = 1;
            }
            else
            {
                ret = LogicaNegocio.context.Lineas.Max(l => l.numLinea) + 1;
            }

            return ret;
        }

        /* Metodo que llena los campos de la interfaz con los valores de la linea seleccionada*/
        private void LineaModif(Linea oldL)
        {
            cmbOrigen.SelectedValue = oldL.municipioOrigen ;
            cmbDestino.SelectedValue = oldL.municipioDestino ;
            cmbHora.Text = oldL.horaInicial.Hour.ToString() + ":" + oldL.horaInicial.Minute.ToString();
            dpLinea.SelectedDate = oldL.horaInicial.Date;
            Intervalo.Text = oldL.intervalo.Hour.ToString()+":"+ oldL.intervalo.Minute.ToString();/*TODO revisar */
        }





    }
}
