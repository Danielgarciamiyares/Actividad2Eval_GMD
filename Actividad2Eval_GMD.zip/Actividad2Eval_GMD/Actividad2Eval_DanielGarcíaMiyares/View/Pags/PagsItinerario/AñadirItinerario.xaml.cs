﻿using Actividad2Eval_DanielGarcíaMiyares.Model;
using Actividad2Eval_DanielGarcíaMiyares.ViewModel;
using CsvHelper;
using System.IO;
using System.Windows;
using System.Windows.Controls;


namespace Actividad2Eval_DanielGarcíaMiyares.View.Pags.PagsItinerario
{
    public partial class AñadirItinerario : Page
    {
        LogicaNegocio contexto = LogicaNegocio.context;
        private Boolean hayParada = false;
        Parada oldParada;

        public AñadirItinerario()
        {
            InitializeComponent();
            fillCombo();
        }


        public AñadirItinerario(Parada p)
        {
            InitializeComponent();
            fillCombo();
            oldParada = p;
            ParadaModif(oldParada);
            hayParada =true;
        }

        private void btnAceptar_Click(object sender, RoutedEventArgs e)
        {
            //ItinerarioView itinerarioView = new ItinerarioView();

            if (!hayParada) 
            { 
                if (!campoVacio())
                {
                    int linea = int.Parse(nLinea.Text);

                    int nParada = -1;

                    nParada = CalcularNParada();


                    Parada p = new Parada(linea, nParada, cmbMunicipio.SelectedValue.ToString(), DateTime.Parse(cmbHora.Text + " " + dpItinerario.Text));

                    if (ValidarIntervaloParada(linea,p))
                    {
                        contexto.Itinerario.Add(p);
                        contexto.SaveItinerarioChanges();

                        this.Visibility = Visibility.Collapsed;/*Borra la pagina*/
                    }
                    else 
                    {
                        MessageBox.Show("Intervalo no válido");
                    }
                }
                else
                {
                    MessageBox.Show("No puede haber ningún campo vacio");
                }
            }
            else
            {
                if (!campoVacio())
                {
                    int linea = int.Parse(nLinea.Text);

                    int nParada = -1;

                    nParada = oldParada.numParada;

                    Parada p = new Parada(linea, nParada, cmbMunicipio.SelectedValue.ToString(), DateTime.Parse(cmbHora.Text + " " + dpItinerario.Text));

                    if (ValidarIntervaloParada(linea, p))
                    {
                        contexto.Itinerario.Add(p);
                        contexto.Itinerario.Remove(oldParada);
                        contexto.SaveItinerarioChanges();

                        this.Visibility = Visibility.Collapsed;/*Borra la pagina*/
                    }
                    else
                    {
                        MessageBox.Show("Intervalo no válido");
                    }
                }
                else
                {
                    MessageBox.Show("No puede haber ningún campo vacio");
                }
            }
        }

        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Visibility = Visibility.Collapsed;/*Borra la pagina*/
        }

        /* Metodo para llenar el combo box de municipios con todos los datos de Municipios.csv*/
        private void fillCombo()
        {
            List<Municipio> lstMunicipio = new List<Municipio>();

            Utilidades u = new Utilidades("Municipios.csv");

            var reader = new StreamReader(u.RutaArchivo);
            using (var csv = new CsvReader(reader, u.config))
            {
                lstMunicipio = new List<Municipio>(csv.GetRecords<Municipio>().ToList());

            }

            this.cmbMunicipio.DisplayMemberPath = "NOMBRE";
            this.cmbMunicipio.SelectedValuePath = "NOMBRE";
            this.cmbMunicipio.ItemsSource = lstMunicipio;
        }

        /* Metodo para validar si hay algún campo vacío en la interfaz
         * Si algún campo esta vacio devuelve true*/
        private bool campoVacio()
        {
            bool ret = false;

            if (cmbMunicipio.SelectedIndex == -1 || cmbHora.Text.Trim().Length == 0 || nLinea.Text.Trim().Length == 0)
            {
                ret = true;
            }
            else
            {
                ret = false;
            }
            return ret;
        }


        /* Metodo para calcular el número de la parada 
         * Si no hubiese ninguna parada le asigna el numero de parada 1
         * Si ya hay alguna le asigna el numero siguiente de la última parada*/
        private int CalcularNParada() 
        {
            int ret = 0;

            if ((contexto.Itinerario.Count)==0)
            {
                ret = 1;
            }
            else
            {
                ret = contexto.Itinerario.Max(i => i.numParada) + 1;
            }

            return ret;
        }


        /* Metodo que llena los campos de la interfaz con los valores de la parada seleccionada */
        private void ParadaModif(Parada oldP)
        {
            nLinea.SelectedText = oldP.numLinea.ToString();
            //p.numParada;
            cmbMunicipio.SelectedValue = oldP.municipio;

            cmbHora.Text = oldP.intervalo.Hour.ToString()+":"+ oldP.intervalo.Minute.ToString();
            dpItinerario.SelectedDate = oldP.intervalo.Date;

        }


        /* TODO acabar y revisar */
        private Boolean validarParada(Parada p)
        {
            Boolean ret = false;

            //LineaView lV = new LineaView();

            List<Linea> lstL = LineaView.lstLineas;

            foreach (Linea l in lstL)
            {
                if (p.numLinea == l.numLinea)
                {
                    ret = true;
                    break;
                }
                else
                {
                    MessageBox.Show("La linea no existe");
                }
            }
            return ret;
        }


        /* Método para validar que el intervalo de una parada en una línea determinada es mayor que el intervalo de la anterior
         * devuelve true si el intervalo de la parada es mayor que el intervalo de la anterior
         * y false en caso contrario */
        public bool ValidarIntervaloParada(int nLinea,Parada pAct)
        {
            //ItinerarioView IV = new ItinerarioView();
            List<Parada> lstFiltrada = new List<Parada>();
            bool ret = false;
            //Parada pAct = null;



            if (ItinerarioView.lstItinerario.Count != 0)/*(ItinerarioView.lstItinerario.Count != 0)*/
            {
                foreach (Parada p in ItinerarioView.lstItinerario.Where(p => p.numLinea == nLinea))/* TODO la ultima parada no se guarda */
                {
                    lstFiltrada.Add(p);
                }
                    if (lstFiltrada.Count != 0)
                    {
                        foreach (Parada p in lstFiltrada)
                        {
                            if (pAct.intervalo > p.intervalo)
                            {
                                ret = true;
                            }
                            else
                            {
                                ret = false;
                                break;
                            }

                        }
                    }
                    else
                    {
                        ret = true;
                    }


            }
            else
            {
                ret = true;
            }

            return ret;
        }















    }
}
