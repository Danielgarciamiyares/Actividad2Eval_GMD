﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2Eval_DanielGarcíaMiyares.Model
{
    public class Parada
    {

        #region Variables
        /*Variables*/
        private int _numLinea;
        private int _numParada;
        private String _municipio;
        private DateTime _intervalo;
        #endregion

        #region Propiedades
        public int numLinea
        {
            get { return _numLinea; }
            set { _numLinea = value; }
        }
        public int numParada
        {
            get { return _numParada; }
            set { _numParada = value; }
        }
        public String municipio
        {
            get { return _municipio; }
            set { _municipio = value; }
        }
        public DateTime intervalo
        {
            get { return _intervalo; }
            set { _intervalo = value; }
        }
        #endregion


        #region Constructores
        /*Constructores*/
        public Parada()
        {

        }

        public Parada(int numLinea, int numParada, String municipio, DateTime intervalo)
        {
            this.numLinea = numLinea;
            this.numParada = numParada;
            this.municipio = municipio;
            this.intervalo = intervalo;
        }
        #endregion

        #region Metodos
        #endregion

    }
}
