﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2Eval_DanielGarcíaMiyares.Model
{
    public class Linea
    {
        #region Variables
        /*Variables*/
        private int _numLinea;
        private String _municipioOrigen;
        private String _municipioDestino;
        private DateTime _horaInicial;
        private TimeOnly _intervalo;


        public int numLinea { get => _numLinea; set  => _numLinea=value; }
        public String municipioOrigen { get => _municipioOrigen; set =>  _municipioOrigen = value; }
        public String municipioDestino { get => _municipioDestino; set => _municipioDestino = value; }
        //[Format("dd/MM/yyyy")]
        public DateTime horaInicial { get => _horaInicial; set => _horaInicial = value; }
        //[Format("HH:mm")]
        public TimeOnly intervalo { get => _intervalo; set => _intervalo = value; }


        #endregion

        #region Constructores
        /*Constructores*/
        public Linea()
        {

        }

        public Linea(int numLinea, String municipioOrigen, String municipioDestino, DateTime horaInicial, TimeOnly intervalo)
        {
            _numLinea = numLinea;
            _municipioOrigen = municipioOrigen;
            _municipioDestino = municipioDestino;
            _horaInicial = horaInicial;
            _intervalo = intervalo;
        }

        #endregion

        #region Metodos
        /*Metodos*/
        public override string? ToString()
        {
            return base.ToString();
        }
        #endregion

    }
}
