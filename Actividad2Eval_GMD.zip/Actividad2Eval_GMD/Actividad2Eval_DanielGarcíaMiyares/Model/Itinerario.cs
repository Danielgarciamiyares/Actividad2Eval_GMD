﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2Eval_DanielGarcíaMiyares.Model
{
    class Itinerario : INotifyPropertyChanged
    {

        #region Variables
        /*Variables*/
        private List<Parada> _lstParadas;
        //private int _numLinea;
        //private int _numParada = 0;
        //private String _municipio;
        //private DateTime _intervalo;

        public event PropertyChangedEventHandler? PropertyChanged;
        #endregion

        #region Propiedades
        public List<Parada> lstParadas
        {
            get { return _lstParadas; }
            set { _lstParadas = value; }
        }
        //public int numLinea
        //{
        //    get { return _numLinea; }
        //    set { _numLinea = value; }
        //}
        //public int numParada 
        //{
        //    get { return _numParada; }
        //    set { _numParada = value; }
        //}
        //public String municipio
        //{
        //    get { return _municipio; }
        //    set { _municipio = value; }
        //}
        //public DateTime intervalo
        //{
        //    get { return _intervalo; }
        //    set { _intervalo = value; }
        //}
        #endregion


        #region Constructores
        /*Constructores*/
        public Itinerario()
        {
            lstParadas = new List<Parada>();
        }

        public Itinerario(List<Parada> lstParadas)/*int numLinea, int numParada, String municipio, DateTime intervalo*/
        {
            this.lstParadas = lstParadas;
            //this.numLinea = numLinea;
            //this.numParada = numParada;
            //this.municipio = municipio;
            //this.intervalo = intervalo;
        }
        #endregion

        #region Metodos
        /*Metodos*/
        public override string? ToString()
        {
            return base.ToString();
        }
        #endregion

    }
}
