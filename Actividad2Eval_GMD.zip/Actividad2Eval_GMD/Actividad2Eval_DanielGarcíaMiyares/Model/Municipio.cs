﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad2Eval_DanielGarcíaMiyares.Model
{
    class Municipio
    {

        private String _CODIGO;
        private String _NOMBRE;


        public String CODIGO {  get => _CODIGO; set => _CODIGO = value; }
        public String NOMBRE { get => _NOMBRE; set => _NOMBRE = value; }


        public Municipio() { }
        public Municipio(String codigo,String nombre)
        {
            _CODIGO = codigo;
            _NOMBRE = nombre;
        }


        public override string? ToString()
        {
            return base.ToString();
        }

    }
}
