namespace TestAppGestionBuses
{
    public class Tests
    {
        String cmbMunicipio = "";
        String cmbHora = "";
        String nLinea = "";

        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void TestCampoVacio()
        {
            bool vacio = campoVacio();
            Assert.That(vacio,Is.True);
        }

        [Test]
        public void Test2()
        {
            int linea = 1;
            int nParada = 1;
            string municipio = "Aramaio";
            string municipio2 = "Maracena";
            string municipio3 = "Kripan";
            DateTime intervalo = DateTime.Now;
            DateTime intervalo2 = DateTime.Parse("09:00");
            DateTime intervalo3 = DateTime.Parse("10:30");

            Parada p = new Parada(linea,nParada,municipio,intervalo);
            Parada p2 = new Parada(linea,nParada+1,municipio2,intervalo2);
            Parada p3 = new Parada(linea,nParada+2,municipio3,intervalo3);

            ItinerarioView.lstItinerario.Add(p2);
            ItinerarioView.lstItinerario.Add(p3);

            bool intervaloCorrecto = ValidarIntervaloParada(linea,p);

            Assert.That(intervaloCorrecto, Is.True);
        }

        #region Metodos

        /* Metodo para validar si hay alg�n campo vac�o en la interfaz
         * Si alg�n campo esta vacio devuelve true*/
        private bool campoVacio()
        {
            bool ret = false;
            /* Codigo adaptado para la clase de pruebas */
            if (cmbMunicipio.Trim().Length == 0 || cmbHora.Trim().Length == 0 || nLinea.Trim().Length == 0)
            /*(cmbMunicipio.SelectedIndex == -1 || cmbHora.Text.Trim().Length == 0 || nLinea.Text.Trim().Length == 0)*//* Codigo original */
            {
                ret = true;
            }
            else
            {
                ret = false;
            }
            return ret;
        }

        /* M�todo para validar que el intervalo de una parada en una l�nea determinada es mayor que el intervalo de la anterior
         * devuelve true si el intervalo de la parada es mayor que el intervalo de la anterior
         * y false en caso contrario */
        public bool ValidarIntervaloParada(int nLinea, Parada pAct)
        {
            List<Parada> lstFiltrada = new List<Parada>();
            bool ret = false;

            if (ItinerarioView.lstItinerario.Count != 0)/*(ItinerarioView.lstItinerario.Count != 0)*/
            {
                foreach (Parada p in ItinerarioView.lstItinerario.Where(p => p.numLinea == nLinea))/* TODO la ultima parada no se guarda */
                {
                    lstFiltrada.Add(p);
                }
                if (lstFiltrada.Count != 0)
                {
                    foreach (Parada p in lstFiltrada)
                    {
                        if (pAct.intervalo > p.intervalo)
                        {
                            ret = true;
                        }
                        else
                        {
                            ret = false;
                            break;
                        }
                    }
                }
                else
                {
                    ret = true;
                }
            }
            else
            {
                ret = true;
            }
            return ret;
        }
        #endregion

        #region Clases para la prueba
        public class Parada
        {
            #region Variables
            /*Variables*/
            private int _numLinea;
            private int _numParada;
            private String _municipio;
            private DateTime _intervalo;
            #endregion

            #region Propiedades
            public int numLinea
            {
                get { return _numLinea; }
                set { _numLinea = value; }
            }
            public int numParada
            {
                get { return _numParada; }
                set { _numParada = value; }
            }
            public String municipio
            {
                get { return _municipio; }
                set { _municipio = value; }
            }
            public DateTime intervalo
            {
                get { return _intervalo; }
                set { _intervalo = value; }
            }
            #endregion

            #region Constructores
            /*Constructores*/
            public Parada()
            {

            }
            public Parada(int numLinea, int numParada, String municipio, DateTime intervalo)
            {
                this.numLinea = numLinea;
                this.numParada = numParada;
                this.municipio = municipio;
                this.intervalo = intervalo;
            }
            #endregion

        }
        public class ItinerarioView
        {
            public static List<Parada> lstItinerario = new List<Parada>();
        }
        #endregion

    }
}